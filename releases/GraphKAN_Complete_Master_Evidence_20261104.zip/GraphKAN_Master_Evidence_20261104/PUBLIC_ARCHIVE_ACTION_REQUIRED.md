# Public archive action required before submission

The previous GitHub repository and release addresses returned HTTP 404 during the October 2026 audit. The manuscript therefore no longer presents either address as an accessible evidence record.

Before submission, the corresponding author must complete the following external actions:

1. Upload the final version locked package to a public immutable archive such as Zenodo.
2. Reserve and then publish the archive DOI.
3. Test the public download in a private browser session without authentication.
4. Replace the pending statement in `manuscript/sections/08_declarations.tex` with the verified DOI and public repository address.
5. Record the final URL, DOI, archive SHA 256, and access date in the release validation record.

These actions require the author's archive and repository accounts and cannot be completed by local source editing alone.
