# Audit revision notes

This revision responds to the scientific audit dated October 30, 2026.

1. The gauge interpretation now distinguishes redundant RBF coefficients from represented lattice pair values. The latter are recovered directly from complete basis log amplitudes and are preserved by minimum norm projection.
2. Figure 2 and Table I are both described as pooled medians over 60 runs. Paired cell effects are explicitly defined as differences between within cell seed medians.
3. The pooled density ordering is corrected: endpoint product has the smallest pooled density median, while endpoint full gives the strongest combined density and correlation comparison used in the paired analysis.
4. The nongeometric control, correlation length, curve landmark, boundary layer width, held out prediction, and normalised error are defined mathematically or operationally.
5. The exact sum optimisation probe and periodic RBM translation projection are reported as exploratory diagnostics with scripts and machine readable outputs.
6. The periodic endpoint reduction is described as a software invariant rather than independent physical evidence.
7. Missing ten site capacity controls and direct pair table Jastrow controls are stated as limitations.
8. Internal campaign labels, the accidental Version of Record paragraph, typographical errors, and the incorrect SineKAN attribution are removed from the manuscript narrative.
9. The data statement now identifies the public repository and retains the persistent archive identifier as a requirement before journal submission.

The revised source compiles to a 15 page main manuscript and a 13 page supplement with no undefined references, missing figures, or overfull boxes.
