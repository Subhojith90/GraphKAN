# Geometry aware neural quantum states manuscript and evidence package

This directory contains the corrected manuscript, Supplemental Material, figures, tables, source data, and deterministic analysis code for the GraphKAN study. The parent package also contains the complete frozen evidence required for the $N=10$ campaign, the matched twelve site confirmation, and the gauge and orthogonal endpoint counterfactual analyses.

## Documents

- `main.tex` is the main manuscript source.
- `supplement.tex` is the Supplemental Material source.
- `main.pdf` and `supplement.pdf` are the verified compiled documents.
- `references.bib`, `main.bbl`, and `supplement.bbl` provide the bibliography sources and resolved bibliography records.

## Compilation

Compile the documents from this directory with:

```bash
tectonic main.tex
tectonic supplement.tex
```

The included BBL files allow compilation without running a separate bibliography command.

## Deterministic analysis

The manuscript figures, tables, and numerical summaries can be regenerated from the validated GraphKAN repository with:

```bash
python scripts/recompute_manuscript_data.py \
  --source-root /path/to/GraphKAN_Publication_Validated \
  --output-root .
```

The analysis environment used for the supplied reconstruction is recorded in `scripts/analysis_environment.txt`.

The added diagnostics can be run from the complete master archive root with:

```bash
python manuscript/scripts/audit_diagnostics/exact_optimization_probe.py \
  --output validation/diagnostics/exact_optimization_probe.json

python manuscript/scripts/audit_diagnostics/rbm_symmetry_probe.py \
  --repository evidence_repository \
  --output validation/diagnostics/rbm_symmetry
```

The first command requires NumPy. The second additionally requires pandas and the frozen campaign checkpoints from the master evidence archive. Both commands create their output directories automatically. The standalone manuscript source ZIP contains the published outputs and scripts but not the full checkpoint collection required by the RBM diagnostic.

## November 2026 audit revision

The revision corrects the interpretation of the minimum norm projection: redundant RBF coefficients are not unique, but lattice pair values reconstructed from the complete Boolean log amplitude are preserved. It also separates pooled run medians from cell level paired effects, corrects the model ordering in the pooled density summary, defines the nongeometric control and scale diagnostics, and identifies the periodic reduction as a software invariant. The post campaign exact sum optimisation and RBM translation projection are included as explicitly exploratory diagnostics. Missing ten site capacity and direct pair table controls remain stated as limitations.

The Results and Discussion remain continuous narratives. The current documents compile to 15 main manuscript pages and 13 supplemental pages.

## Integrity

`MANIFEST_SHA256.txt` records the SHA 256 digest of every supplied file other than the manifest itself. The companion checksum beside the final ZIP verifies the archive as a whole.
