#!/usr/bin/env python3
"""Deterministic reanalysis and figure generation for the GraphKAN AMO NQS manuscript.

This script performs no new variational Monte Carlo training. It reads the frozen
Stage 4F-R campaign, run bundles, checkpoints, and source code outputs, then
recomputes manuscript-level summaries, paired fixed-grid bootstrap intervals,
periodic equality checks, diagnostic gauge canonicalization, and publication figures.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import platform
import sys
from pathlib import Path
from typing import Iterable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle
import numpy as np
import pandas as pd

MODEL_ORDER = [
    "rbf_radial_b32",
    "endpoint_sum_b32",
    "endpoint_product_b32",
    "endpoint_hybrid_b32",
    "endpoint_full_b32",
    "mlp_endpoint_medium",
    "mlp_endpoint_large",
    "rbm_h32",
]
MODEL_DISPLAY = {
    "rbf_radial_b32": "Radial RBF",
    "endpoint_sum_b32": "Endpoint sum",
    "endpoint_product_b32": "Endpoint product",
    "endpoint_hybrid_b32": "Endpoint hybrid",
    "endpoint_full_b32": "Endpoint full",
    "mlp_endpoint_medium": "MLP medium",
    "mlp_endpoint_large": "MLP large",
    "rbm_h32": "RBM h32",
}
ENDPOINT_MODELS = [
    "endpoint_sum_b32",
    "endpoint_product_b32",
    "endpoint_hybrid_b32",
    "endpoint_full_b32",
]
METRICS = {
    "energy": "exact_model_abs_energy_error_to_ed",
    "density": "exact_model_density_mae_to_ed",
    "correlation": "exact_model_connected_correlation_mae_to_ed",
}
METRIC_LABELS = {
    "energy": r"$|E-E_0|$",
    "density": "Density MAE",
    "correlation": "Connected correlation MAE",
}
BOOTSTRAP_REPS = 20_000
BOOTSTRAP_SEED = 20_260_723


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def bootstrap_median(values: Iterable[float], reps: int = BOOTSTRAP_REPS, seed: int = BOOTSTRAP_SEED) -> tuple[float, float, float]:
    x = np.asarray(list(values), dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return math.nan, math.nan, math.nan
    estimate = float(np.median(x))
    if x.size == 1:
        return estimate, estimate, estimate
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, x.size, size=(reps, x.size), endpoint=False)
    distribution = np.median(x[indices], axis=1)
    low, high = np.quantile(distribution, [0.025, 0.975])
    return estimate, float(low), float(high)


def read_run_tables(runs_root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    site_parts: list[pd.DataFrame] = []
    corr_parts: list[pd.DataFrame] = []
    history_parts: list[pd.DataFrame] = []
    for run_dir in sorted(p for p in runs_root.iterdir() if p.is_dir()):
        site_path = run_dir / "site_observables.csv"
        corr_path = run_dir / "corr_observables.csv"
        history_path = run_dir / "history.csv"
        if site_path.exists():
            site_parts.append(pd.read_csv(site_path))
        if corr_path.exists():
            corr_parts.append(pd.read_csv(corr_path))
        if history_path.exists():
            history_parts.append(pd.read_csv(history_path))
    if not site_parts or not corr_parts:
        raise RuntimeError("Frozen run observables are missing")
    return (
        pd.concat(site_parts, ignore_index=True),
        pd.concat(corr_parts, ignore_index=True),
        pd.concat(history_parts, ignore_index=True),
    )


def model_boundary_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (boundary, model), group in df.groupby(["boundary_condition", "model_label"], sort=False):
        row = {
            "boundary": boundary,
            "model_label": model,
            "model": MODEL_DISPLAY.get(model, model),
            "registered_runs": int(len(group)),
            "exact_valid_runs": int((group["scientific_validity_exact"] == "VALID").sum()),
            "sampled_valid_runs": int((group["scientific_validity_sample"] == "VALID").sum()),
            "exact_valid_rate": float((group["scientific_validity_exact"] == "VALID").mean()),
            "sampled_valid_rate": float((group["scientific_validity_sample"] == "VALID").mean()),
            "parameters": int(group["n_parameters"].median()),
            "median_wall_seconds": float(group["wall_seconds"].median()),
        }
        for short, column in METRICS.items():
            row[f"median_{short}"] = float(group[column].median())
            row[f"q25_{short}"] = float(group[column].quantile(0.25))
            row[f"q75_{short}"] = float(group[column].quantile(0.75))
        rows.append(row)
    out = pd.DataFrame(rows)
    order = {name: i for i, name in enumerate(MODEL_ORDER)}
    out["model_order"] = out["model_label"].map(order)
    return out.sort_values(["boundary", "model_order"]).reset_index(drop=True)


def cell_medians(df: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["boundary_condition", "delta", "c6", "model_label"]
    columns = list(METRICS.values()) + ["wall_seconds", "n_parameters"]
    out = df.groupby(group_cols, as_index=False)[columns].median()
    rename = {value: f"median_{key}" for key, value in METRICS.items()}
    rename.update({"wall_seconds": "median_wall_seconds", "n_parameters": "parameters"})
    return out.rename(columns=rename).rename(columns={"boundary_condition": "boundary"})


def paired_effects(cell: pd.DataFrame, controls: list[str]) -> pd.DataFrame:
    rows: list[dict] = []
    for boundary in ["open", "periodic"]:
        for control in controls:
            base = cell[(cell.boundary == boundary) & (cell.model_label == control)].set_index(["delta", "c6"])
            for treated in MODEL_ORDER:
                if treated == control:
                    continue
                tr = cell[(cell.boundary == boundary) & (cell.model_label == treated)].set_index(["delta", "c6"])
                common = base.index.intersection(tr.index)
                if common.empty:
                    continue
                for metric in METRICS:
                    column = f"median_{metric}"
                    deltas = (tr.loc[common, column] - base.loc[common, column]).to_numpy(dtype=float)
                    estimate, low, high = bootstrap_median(deltas)
                    rows.append({
                        "boundary": boundary,
                        "treated": treated,
                        "treated_display": MODEL_DISPLAY[treated],
                        "control": control,
                        "control_display": MODEL_DISPLAY[control],
                        "metric": metric,
                        "cells": int(len(deltas)),
                        "median_delta": estimate,
                        "ci95_low": low,
                        "ci95_high": high,
                        "mean_delta": float(np.mean(deltas)),
                        "fraction_cells_treated_lower": float(np.mean(deltas < 0)),
                        "all_cells_treated_lower": bool(np.all(deltas < 0)),
                        "bootstrap_reps": BOOTSTRAP_REPS,
                        "bootstrap_seed": BOOTSTRAP_SEED,
                    })
    return pd.DataFrame(rows)


def add_boundary_columns(table: pd.DataFrame) -> pd.DataFrame:
    out = table.copy()
    out["boundary"] = out["run_id"].str.extract(r"__B(open|periodic)__", expand=False)
    return out


def density_summaries(site: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    data = add_boundary_columns(site)
    distance = np.minimum(data["site"].to_numpy(), data["n_sites"].to_numpy() - 1 - data["site"].to_numpy())
    data["boundary_distance"] = distance.astype(int)
    data["region"] = np.where(distance == 0, "edge", np.where(distance == 1, "near_edge", "bulk"))

    regional = data.groupby(["boundary", "model_label", "region"], as_index=False).agg(
        median_exact_abs_error=("exact_model_abs_error", "median"),
        q25_exact_abs_error=("exact_model_abs_error", lambda x: x.quantile(0.25)),
        q75_exact_abs_error=("exact_model_abs_error", lambda x: x.quantile(0.75)),
        observations=("exact_model_abs_error", "size"),
    )
    regional["model"] = regional["model_label"].map(MODEL_DISPLAY)
    regional["estimand"] = "pooled_site_error_median"
    regional["aggregation_hierarchy"] = "pooled individual site-level errors over registered runs and sites within region"

    site_resolved = data.groupby(["boundary", "model_label", "site", "boundary_distance"], as_index=False).agg(
        median_exact_abs_error=("exact_model_abs_error", "median"),
        q25_exact_abs_error=("exact_model_abs_error", lambda x: x.quantile(0.25)),
        q75_exact_abs_error=("exact_model_abs_error", lambda x: x.quantile(0.75)),
        observations=("exact_model_abs_error", "size"),
    )
    site_resolved["model"] = site_resolved["model_label"].map(MODEL_DISPLAY)

    run_region = data.groupby(
        ["boundary", "delta", "c6", "seed", "model_label", "region"], as_index=False
    )["exact_model_abs_error"].mean()
    rows: list[dict] = []
    for boundary in ["open", "periodic"]:
        radial = run_region[(run_region.boundary == boundary) & (run_region.model_label == "rbf_radial_b32")]
        for treated in ENDPOINT_MODELS + ["mlp_endpoint_medium", "mlp_endpoint_large"]:
            tr = run_region[(run_region.boundary == boundary) & (run_region.model_label == treated)]
            merged = tr.merge(
                radial,
                on=["boundary", "delta", "c6", "seed", "region"],
                suffixes=("_treated", "_radial"),
            )
            merged["seed_delta"] = merged["exact_model_abs_error_treated"] - merged["exact_model_abs_error_radial"]
            cell = merged.groupby(["delta", "c6", "region"], as_index=False)["seed_delta"].median()
            for region, group in cell.groupby("region"):
                estimate, low, high = bootstrap_median(group["seed_delta"].to_numpy())
                rows.append({
                    "boundary": boundary,
                    "treated": treated,
                    "treated_display": MODEL_DISPLAY[treated],
                    "control": "rbf_radial_b32",
                    "region": region,
                    "cells": int(len(group)),
                    "median_cell_delta": estimate,
                    "ci95_low": low,
                    "ci95_high": high,
                    "fraction_cells_treated_lower": float(np.mean(group["seed_delta"] < 0)),
                    "bootstrap_reps": BOOTSTRAP_REPS,
                    "bootstrap_seed": BOOTSTRAP_SEED,
                })
    effects = pd.DataFrame(rows)
    effects["estimand"] = "grid_median_of_cell_medians"
    effects["aggregation_hierarchy"] = (
        "run_region_mean -> matched_seed_difference -> cell_median_difference -> grid_median_of_cell_medians"
    )
    return regional, site_resolved, effects


def correlation_by_separation(corr: pd.DataFrame) -> pd.DataFrame:
    data = add_boundary_columns(corr)
    data = data[data["i"] < data["j"]].copy()
    raw = (data["i"] - data["j"]).abs().astype(int)
    data["separation"] = np.where(
        data["boundary"] == "periodic",
        np.minimum(raw, data["n_sites"] - raw),
        raw,
    )
    out = data.groupby(["boundary", "model_label", "separation"], as_index=False).agg(
        median_exact_abs_error=("exact_model_abs_error", "median"),
        q25_exact_abs_error=("exact_model_abs_error", lambda x: x.quantile(0.25)),
        q75_exact_abs_error=("exact_model_abs_error", lambda x: x.quantile(0.75)),
        observations=("exact_model_abs_error", "size"),
    )
    out["model"] = out["model_label"].map(MODEL_DISPLAY)
    return out


def checkpoint_equal(path_a: Path, path_b: Path) -> bool:
    za = np.load(path_a)
    zb = np.load(path_b)
    if za.files != zb.files:
        return False
    return all(np.array_equal(za[key], zb[key]) for key in za.files)


def periodic_invariance(df: pd.DataFrame, runs_root: Path) -> pd.DataFrame:
    radial = df[(df.boundary_condition == "periodic") & (df.model_label == "rbf_radial_b32")].set_index(["delta", "c6", "seed"])
    rows: list[dict] = []
    for model in ENDPOINT_MODELS:
        treated = df[(df.boundary_condition == "periodic") & (df.model_label == model)].set_index(["delta", "c6", "seed"])
        common = radial.index.intersection(treated.index)
        record: dict = {
            "model_label": model,
            "model": MODEL_DISPLAY[model],
            "paired_runs": int(len(common)),
            "checkpoint_equal_count": 0,
            "checkpoint_unequal_count": 0,
        }
        for short, column in METRICS.items():
            delta = (treated.loc[common, column] - radial.loc[common, column]).to_numpy(dtype=float)
            record[f"max_abs_{short}_delta"] = float(np.max(np.abs(delta)))
            record[f"all_{short}_deltas_exactly_zero"] = bool(np.all(delta == 0.0))
        for delta_value, c6_value, seed in common:
            treated_id = treated.loc[(delta_value, c6_value, seed), "run_id"]
            radial_id = radial.loc[(delta_value, c6_value, seed), "run_id"]
            equal = checkpoint_equal(runs_root / treated_id / "checkpoint.npz", runs_root / radial_id / "checkpoint.npz")
            if equal:
                record["checkpoint_equal_count"] += 1
            else:
                record["checkpoint_unequal_count"] += 1
        record["all_checkpoint_tensors_equal"] = record["checkpoint_unequal_count"] == 0
        rows.append(record)
    return pd.DataFrame(rows)


def pair_feature_matrices(n_sites: int, n_basis: int, boundary: str) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    i, j = np.triu_indices(n_sites, k=1)
    raw_distance = np.abs(i - j).astype(float)
    if boundary == "periodic":
        r = np.minimum(raw_distance, n_sites - raw_distance)
    else:
        r = raw_distance
    centers = np.linspace(float(r.min()), float(r.max()), n_basis)
    width = max(float(np.ptp(centers)) / max(n_basis - 1, 1), 1e-6)
    basis = np.exp(-0.5 * ((r[:, None] - centers[None, :]) / width) ** 2)
    site_d = np.minimum(np.arange(n_sites), n_sites - 1 - np.arange(n_sites)).astype(float)
    site_d /= max(float(site_d.max()), 1.0)
    endpoint = np.stack(
        [site_d[i] + site_d[j], np.abs(site_d[i] - site_d[j]), site_d[i] * site_d[j]],
        axis=1,
    )
    if boundary == "periodic":
        endpoint[:] = 0.0
    return i, j, r, basis, endpoint


def matrix_rank_records(n_sites: int = 10, n_basis: int = 32) -> tuple[pd.DataFrame, dict[str, np.ndarray]]:
    states = np.asarray(list(itertools.product([0.0, 1.0], repeat=n_sites)), dtype=float)
    rows: list[dict] = []
    spectra: dict[str, np.ndarray] = {}
    for boundary in ["open", "periodic"]:
        i, j, _, basis, endpoint = pair_feature_matrices(n_sites, n_basis, boundary)
        pair_occ = states[:, i] * states[:, j]
        specs = {
            "rbf_radial_b32": basis,
            "endpoint_sum_b32": np.column_stack([basis, endpoint[:, 0]]) if boundary == "open" else basis,
            "endpoint_product_b32": np.column_stack([basis, endpoint[:, 2]]) if boundary == "open" else basis,
            "endpoint_hybrid_b32": np.column_stack([basis, endpoint[:, [0, 2]]]) if boundary == "open" else basis,
            "endpoint_full_b32": np.column_stack([basis, endpoint]) if boundary == "open" else basis,
        }
        for model, pair_parameter_map in specs.items():
            design = np.column_stack([states, pair_occ @ pair_parameter_map])
            singular = np.linalg.svd(design, compute_uv=False)
            tolerance = max(design.shape) * np.finfo(float).eps * singular[0]
            rank = int(np.count_nonzero(singular > tolerance))
            nonzero = singular[singular > tolerance]
            spectra[f"{boundary}__{model}"] = singular
            rows.append({
                "boundary": boundary,
                "model_label": model,
                "model": MODEL_DISPLAY[model],
                "design_rows": int(design.shape[0]),
                "parameter_columns": int(design.shape[1]),
                "numerical_rank": rank,
                "nullity": int(design.shape[1] - rank),
                "rank_tolerance": float(tolerance),
                "largest_singular_value": float(singular[0]),
                "smallest_nonzero_singular_value": float(nonzero[-1]),
                "nonzero_condition_number": float(nonzero[0] / nonzero[-1]),
                "complete_boolean_basis": True,
            })
    return pd.DataFrame(rows), spectra


def gauge_diagnostics(df: pd.DataFrame, runs_root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    i, j, distance, basis, endpoint = pair_feature_matrices(10, 32, "open")
    rows: list[dict] = []
    coefficient_rows: list[dict] = []
    open_pair = df[(df.boundary_condition == "open") & (df.model_label.isin(["rbf_radial_b32"] + ENDPOINT_MODELS))]
    for record in open_pair.itertuples(index=False):
        checkpoint = np.load(runs_root / record.run_id / "checkpoint.npz")
        arrays = [checkpoint[key] for key in checkpoint.files]
        if record.model_label == "rbf_radial_b32":
            endpoint_coeff = np.empty((0,), dtype=float)
            radial_coeff = np.asarray(arrays[0], dtype=float)
        else:
            endpoint_coeff = np.asarray(arrays[0], dtype=float)
            radial_coeff = np.asarray(arrays[1], dtype=float)
        values = basis @ radial_coeff
        if record.model_label == "endpoint_sum_b32":
            values = values + endpoint[:, 0] * endpoint_coeff[0]
        elif record.model_label == "endpoint_product_b32":
            values = values + endpoint[:, 2] * endpoint_coeff[0]
        elif record.model_label == "endpoint_hybrid_b32":
            values = values + endpoint[:, [0, 2]] @ endpoint_coeff
        elif record.model_label == "endpoint_full_b32":
            values = values + endpoint @ endpoint_coeff
        centered = values - values.mean()
        rms = float(np.sqrt(np.mean(centered**2)))
        normalized = centered / rms if rms > 1e-14 else centered
        for index in range(len(values)):
            rows.append({
                "run_id": record.run_id,
                "model_label": record.model_label,
                "model": MODEL_DISPLAY[record.model_label],
                "delta": float(record.delta),
                "c6": float(record.c6),
                "seed": int(record.seed),
                "pair_i": int(i[index]),
                "pair_j": int(j[index]),
                "distance": float(distance[index]),
                "endpoint_sum": float(endpoint[index, 0]),
                "endpoint_difference": float(endpoint[index, 1]),
                "endpoint_product": float(endpoint[index, 2]),
                "raw_pair_value": float(values[index]),
                "centered_pair_value": float(centered[index]),
                "rms_normalized_pair_value": float(normalized[index]),
            })
        coefficient_rows.append({
            "run_id": record.run_id,
            "model_label": record.model_label,
            "delta": float(record.delta),
            "c6": float(record.c6),
            "seed": int(record.seed),
            "pair_curve_rms": rms,
            "radial_coefficient_l2": float(np.linalg.norm(radial_coeff)),
            "endpoint_sum_coefficient": float(endpoint_coeff[0]) if record.model_label in {"endpoint_sum_b32", "endpoint_hybrid_b32", "endpoint_full_b32"} else math.nan,
            "endpoint_difference_coefficient": float(endpoint_coeff[1]) if record.model_label == "endpoint_full_b32" else math.nan,
            "endpoint_product_coefficient": float(endpoint_coeff[-1]) if record.model_label in {"endpoint_product_b32", "endpoint_hybrid_b32", "endpoint_full_b32"} else math.nan,
        })
    values = pd.DataFrame(rows)
    coefficients = pd.DataFrame(coefficient_rows)
    stability_rows: list[dict] = []
    for (model, delta_value, c6_value), group in values.groupby(["model_label", "delta", "c6"]):
        pivot = group.pivot_table(
            index=["pair_i", "pair_j"], columns="seed", values="rms_normalized_pair_value"
        )
        correlation = pivot.corr().to_numpy(dtype=float)
        upper = correlation[np.triu_indices_from(correlation, k=1)]
        stability_rows.append({
            "model_label": model,
            "model": MODEL_DISPLAY[model],
            "delta": delta_value,
            "c6": c6_value,
            "seed_count": int(pivot.shape[1]),
            "median_pairwise_curve_correlation": float(np.nanmedian(upper)),
            "minimum_pairwise_curve_correlation": float(np.nanmin(upper)),
            "maximum_pairwise_curve_correlation": float(np.nanmax(upper)),
            "diagnostic_only": True,
        })
    return values, coefficients, pd.DataFrame(stability_rows)


def failure_inventory(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    flagged = df[(df.scientific_validity_exact != "VALID") | (df.scientific_validity_sample != "VALID")].copy()
    details = flagged[[
        "run_id", "boundary_condition", "delta", "c6", "model_label", "seed",
        "scientific_validity_exact", "scientific_validity_sample", "exact_health_flags",
        "sample_health_flags", "exact_model_abs_energy_error_to_ed",
        "exact_model_density_mae_to_ed", "exact_model_connected_correlation_mae_to_ed",
    ]].rename(columns={"boundary_condition": "boundary"})
    summary = df.groupby(["boundary_condition", "model_label"], as_index=False).agg(
        runs=("run_id", "size"),
        exact_flagged=("scientific_validity_exact", lambda x: int((x != "VALID").sum())),
        sampled_flagged=("scientific_validity_sample", lambda x: int((x != "VALID").sum())),
    ).rename(columns={"boundary_condition": "boundary"})
    summary["model"] = summary["model_label"].map(MODEL_DISPLAY)
    return details, summary


def parameter_count_table() -> pd.DataFrame:
    rows = [
        ("open", "rbf_radial_b32", "10 site fields + 32 RBF coefficients", 42),
        ("open", "endpoint_sum_b32", "10 + 32 + 1 endpoint sum coefficient", 43),
        ("open", "endpoint_product_b32", "10 + 32 + 1 endpoint product coefficient", 43),
        ("open", "endpoint_hybrid_b32", "10 + 32 + 2 endpoint coefficients", 44),
        ("open", "endpoint_full_b32", "10 + 32 + 3 endpoint coefficients", 45),
        ("open", "mlp_endpoint_medium", "10 + (15 x 7 + 7) + (7 x 1 + 1)", 130),
        ("open", "mlp_endpoint_large", "10 + (20 x 11 + 11) + (11 x 1 + 1)", 253),
        ("open", "rbm_h32", "10 visible + 10 x 32 weights + 32 hidden", 362),
        ("periodic", "rbf_radial_b32", "10 site fields + 32 RBF coefficients", 42),
        ("periodic", "endpoint_sum_b32", "Endpoint disabled reduction to radial", 42),
        ("periodic", "endpoint_product_b32", "Endpoint disabled reduction to radial", 42),
        ("periodic", "endpoint_hybrid_b32", "Endpoint disabled reduction to radial", 42),
        ("periodic", "endpoint_full_b32", "Endpoint disabled reduction to radial", 42),
        ("periodic", "mlp_endpoint_medium", "10 + (12 x 7 + 7) + (7 x 1 + 1)", 109),
        ("periodic", "mlp_endpoint_large", "10 + (17 x 11 + 11) + (11 x 1 + 1)", 220),
        ("periodic", "rbm_h32", "10 visible + 10 x 32 weights + 32 hidden", 362),
    ]
    out = pd.DataFrame(rows, columns=["boundary", "model_label", "derivation", "derived_parameters"])
    out["model"] = out["model_label"].map(MODEL_DISPLAY)
    return out


def convergence_summary(history: pd.DataFrame) -> pd.DataFrame:
    data = add_boundary_columns(history)
    out = data.groupby(["boundary", "model_label", "step"], as_index=False).agg(
        median_sampled_energy=("energy_mean", "median"),
        q25_sampled_energy=("energy_mean", lambda x: x.quantile(0.25)),
        q75_sampled_energy=("energy_mean", lambda x: x.quantile(0.75)),
        trajectories=("energy_mean", "size"),
    )
    out["model"] = out["model_label"].map(MODEL_DISPLAY)
    return out


def save_csv(table: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(path, index=False)


def fig_model_schematic(path: Path) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(7.2, 4.7), gridspec_kw={"height_ratios": [1.08, 1.0]})
    ax = axes[0]
    ax.set_xlim(-0.5, 10.4)
    ax.set_ylim(-1.45, 2.0)
    for site in range(10):
        rect = Rectangle((site, 0), 0.68, 0.68, fill=False, linewidth=0.95)
        ax.add_patch(rect)
        ax.text(site + 0.34, 0.34, str(site + 1), ha="center", va="center", fontsize=7.2)
    ax.text(-0.35, 1.65, "Open chain", fontsize=10, weight="bold")
    ax.plot([0.34, 2.34], [0.92, 0.92], marker="o", linewidth=1)
    ax.plot([4.34, 6.34], [1.12, 1.12], marker="s", linewidth=1)
    ax.annotate(
        "equal separation, distinct boundary environments",
        xy=(6.34, 1.12), xytext=(3.45, 1.62),
        arrowprops={"arrowstyle": "->", "linewidth": 0.8}, fontsize=7.7,
    )
    expression = (
        r"$F_{ij}=\sum_k a_k B_k(r_{ij}/R_\Omega)"
        r"+\beta_s(d_i+d_j)+\beta_d|d_i-d_j|+\beta_p d_i d_j$"
    )
    ax.text(0.0, -0.62, expression, fontsize=8.4)
    ax.text(
        0.0,
        -1.12,
        r"$d_i=\frac{\min(i-1,N-i)}{\lfloor(N-1)/2\rfloor},\quad i=1,\ldots,N$; ablations retain selected endpoint terms.",
        fontsize=7.5,
    )
    ax.axis("off")

    ax = axes[1]
    ax.set_aspect("equal")
    center = np.array([2.0, 0.0])
    radius = 1.08
    points = []
    for k in range(10):
        # Start at the top and number clockwise so the cyclic ordering is
        # visually unambiguous: 1 -> 2 -> ... -> 10 -> 1.
        angle = np.pi / 2 - 2 * np.pi * k / 10
        point = center + radius * np.array([np.cos(angle), np.sin(angle)])
        points.append(point)
        ax.add_patch(Circle(point, 0.105, fill=False, linewidth=0.9))
        ax.text(point[0], point[1], str(k + 1), ha="center", va="center", fontsize=5.8)
    for k in range(10):
        a, b = points[k], points[(k + 1) % 10]
        ax.plot([a[0], b[0]], [a[1], b[1]], linewidth=0.75, color="0.35")
    ax.text(0.15, 1.5, "Periodic control", fontsize=10, weight="bold")
    ax.text(0.15, -1.43, r"Sequential cyclic order: $1\rightarrow2\rightarrow\cdots\rightarrow10\rightarrow1$", fontsize=7.3)
    ax.text(3.55, 0.55, "Minimum image distances", fontsize=7.8)
    ax.text(3.55, 0.15, "Endpoint features disabled", fontsize=7.8)
    ax.text(3.55, -0.25, "Endpoint labels reduce to radial", fontsize=7.8)
    ax.text(3.55, -0.65, "Exact metrics and checkpoints coincide", fontsize=7.8)
    ax.annotate("", xy=(3.37, 0.0), xytext=(3.02, 0.0), arrowprops={"arrowstyle": "->", "linewidth": 0.8})
    ax.set_xlim(-0.1, 6.65)
    ax.set_ylim(-1.55, 1.65)
    ax.axis("off")
    fig.tight_layout(h_pad=0.25)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)

def fig_model_metrics(summary: pd.DataFrame, path: Path) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 3.35), sharex=True)
    x = np.arange(len(MODEL_ORDER))
    for ax, metric in zip(axes, ["energy", "density", "correlation"]):
        for boundary, marker, offset in [("open", "o", -0.12), ("periodic", "s", 0.12)]:
            group = summary[summary.boundary == boundary].set_index("model_label").reindex(MODEL_ORDER)
            ax.scatter(x + offset, group[f"median_{metric}"], marker=marker, label=boundary.capitalize(), s=28)
        ax.set_yscale("log")
        ax.set_title(METRIC_LABELS[metric], fontsize=9)
        ax.grid(axis="y", alpha=0.25)
        ax.set_xticks(x)
        ax.set_xticklabels([MODEL_DISPLAY[m] for m in MODEL_ORDER], rotation=68, ha="right", fontsize=6.6)
    axes[0].set_ylabel("Median exact error")
    axes[0].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def fig_paired_effects(paired: pd.DataFrame, path: Path) -> None:
    data = paired[(paired.boundary == "open") & (paired.control == "rbf_radial_b32") & paired.treated.isin(ENDPOINT_MODELS)]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.95))
    y = np.arange(len(ENDPOINT_MODELS))
    for index, metric in enumerate(["energy", "density", "correlation"]):
        ax = axes[index]
        group = data[data.metric == metric].set_index("treated").reindex(ENDPOINT_MODELS)
        x = group.median_delta.to_numpy()
        low = group.ci95_low.to_numpy()
        high = group.ci95_high.to_numpy()
        ax.errorbar(x, y, xerr=np.vstack([x - low, high - x]), fmt="o", capsize=2.5, linewidth=1)
        ax.axvline(0, linewidth=0.8)
        ax.set_title(METRIC_LABELS[metric], fontsize=9)
        ax.grid(axis="x", alpha=0.25)
        ax.set_xlabel("Endpoint minus radial")
        ax.set_yticks(y)
        if index == 0:
            ax.set_yticklabels([MODEL_DISPLAY[m] for m in ENDPOINT_MODELS], fontsize=7.4)
        else:
            ax.set_yticklabels([])
        ax.invert_yaxis()
    fig.suptitle("Paired cell median effects over 12 registered open chain cells", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)

def fig_density(site_resolved: pd.DataFrame, regional: pd.DataFrame, path: Path) -> None:
    models = ["rbf_radial_b32", "endpoint_full_b32", "endpoint_hybrid_b32", "mlp_endpoint_medium"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw={"width_ratios": [1.25, 1]})
    ax = axes[0]
    for model, marker in zip(models, ["o", "s", "^", "D"]):
        group = site_resolved[(site_resolved.boundary == "open") & (site_resolved.model_label == model)].sort_values("site")
        ax.plot(group.site + 1, group.median_exact_abs_error, marker=marker, linewidth=1, markersize=3.5, label=MODEL_DISPLAY[model])
    ax.set_yscale("log")
    ax.set_xlabel("Site")
    ax.set_ylabel("Median exact density error")
    ax.set_xticks(np.arange(1, 11))
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, fontsize=6.8)
    ax.set_title("Site resolved", fontsize=9)

    ax = axes[1]
    regions = ["edge", "near_edge", "bulk"]
    width = 0.18
    x = np.arange(len(regions))
    for index, model in enumerate(models):
        group = regional[(regional.boundary == "open") & (regional.model_label == model)].set_index("region").reindex(regions)
        ax.bar(x + (index - 1.5) * width, group.median_exact_abs_error, width=width, label=MODEL_DISPLAY[model])
    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(["Edge", "Near edge", "Bulk"], rotation=18)
    ax.set_title("Boundary regions", fontsize=9)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def fig_correlation(corr_sep: pd.DataFrame, path: Path) -> None:
    models = ["rbf_radial_b32", "endpoint_full_b32", "endpoint_hybrid_b32", "mlp_endpoint_medium"]
    fig, ax = plt.subplots(figsize=(4.9, 3.15))
    for model, marker in zip(models, ["o", "s", "^", "D"]):
        group = corr_sep[(corr_sep.boundary == "open") & (corr_sep.model_label == model)].sort_values("separation")
        ax.plot(group.separation, group.median_exact_abs_error, marker=marker, markersize=3.7, linewidth=1, label=MODEL_DISPLAY[model])
    ax.set_yscale("log")
    ax.set_xticks(np.arange(1, 10))
    ax.set_xlabel(r"Separation $|i-j|$")
    ax.set_ylabel("Median exact connected correlation error")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def fig_periodic_health(periodic: pd.DataFrame, health: pd.DataFrame, path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.55), gridspec_kw={"width_ratios": [1.15, 1.2]})
    ax = axes[0]
    ax.axis("off")
    ax.text(0.0, 1.03, "Periodic endpoint disabled invariance", transform=ax.transAxes, fontsize=9, weight="bold")
    headers = ["Variant", "Exact metric\npairs", r"max $|\Delta|$", "Equal\ncheckpoints"]
    x_positions = [0.0, 0.38, 0.67, 0.9]
    alignments = ["left", "center", "center", "center"]
    for x, header, alignment in zip(x_positions, headers, alignments):
        ax.text(x, 0.87, header, transform=ax.transAxes, fontsize=6.6, weight="bold", ha=alignment, va="bottom")
    for row_index, record in enumerate(periodic.itertuples(index=False)):
        y = 0.70 - 0.15 * row_index
        max_delta = max(record.max_abs_energy_delta, record.max_abs_density_delta, record.max_abs_correlation_delta)
        ax.text(0.0, y, MODEL_DISPLAY[record.model_label].replace("Endpoint ", ""), transform=ax.transAxes, fontsize=7.2)
        ax.text(0.38, y, str(record.paired_runs), transform=ax.transAxes, fontsize=7.2, ha="center")
        ax.text(0.67, y, "0" if max_delta == 0 else f"{max_delta:.2e}", transform=ax.transAxes, fontsize=7.2, ha="center")
        ax.text(0.9, y, f"{record.checkpoint_equal_count}/{record.paired_runs}", transform=ax.transAxes, fontsize=7.2, ha="center")
    ax.text(0.0, 0.05, "Totals: 240 exact metric pairs; 240 checkpoints have equal tensor values.", transform=ax.transAxes, fontsize=6.7)

    ax = axes[1]
    ordered = health.set_index(["boundary", "model_label"])
    matrix = []
    labels = []
    for boundary in ["open", "periodic"]:
        for model in MODEL_ORDER:
            row = ordered.loc[(boundary, model)]
            matrix.append([1 - row.exact_flagged / row.runs, 1 - row.sampled_flagged / row.runs])
            labels.append(f"{boundary[0].upper()} {MODEL_DISPLAY[model]}")
    matrix_array = np.asarray(matrix)
    image = ax.imshow(matrix_array, aspect="auto", vmin=0, vmax=1)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Exact", "Sampled"], fontsize=7)
    ax.set_yticks(np.arange(len(labels)))
    ax.set_yticklabels(labels, fontsize=5.5)
    ax.set_title("Retained health outcomes", fontsize=9)
    for i_row in range(matrix_array.shape[0]):
        for j_col in range(2):
            ax.text(j_col, i_row, f"{matrix_array[i_row, j_col]:.2f}", ha="center", va="center", fontsize=5.0)
    fig.colorbar(image, ax=ax, fraction=0.04, pad=0.02, label="Valid fraction")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)

def fig_gauge(values: pd.DataFrame, stability: pd.DataFrame, path: Path) -> None:
    models = ENDPOINT_MODELS
    fig, axes = plt.subplots(2, 2, figsize=(7.0, 5.0), sharex=True, sharey=True)
    for ax, model in zip(axes.ravel(), models):
        group = values[values.model_label == model].copy()
        aggregate = group.groupby(["pair_i", "pair_j", "distance"], as_index=False).agg(
            median=("rms_normalized_pair_value", "median"),
            q25=("rms_normalized_pair_value", lambda x: x.quantile(0.25)),
            q75=("rms_normalized_pair_value", lambda x: x.quantile(0.75)),
        )
        ax.scatter(aggregate.distance, aggregate["median"], s=12)
        for distance_value, sub in aggregate.groupby("distance"):
            ax.vlines(np.full(len(sub), distance_value), sub.q25, sub.q75, linewidth=0.6)
        median_corr = stability[stability.model_label == model].median_pairwise_curve_correlation.median()
        ax.set_title(f"{MODEL_DISPLAY[model]}\nmedian seed correlation={median_corr:.3f}", fontsize=8)
        ax.grid(alpha=0.2)
    for ax in axes[-1, :]:
        ax.set_xlabel("Pair separation")
    fig.supylabel("Centred, RMS normalised pair value", x=0.01, fontsize=8.5)
    fig.suptitle("Represented lattice pair values after coefficient projection", fontsize=9.5)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def fig_singular_values(spectra: dict[str, np.ndarray], path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0))
    for ax, boundary in zip(axes, ["open", "periodic"]):
        for model, marker in zip(["rbf_radial_b32", "endpoint_hybrid_b32", "endpoint_full_b32"], ["o", "s", "^"]):
            values = spectra[f"{boundary}__{model}"]
            ax.plot(np.arange(1, len(values) + 1), values, marker=marker, markersize=2.5, linewidth=0.8, label=MODEL_DISPLAY[model])
        ax.set_yscale("log")
        ax.set_xlabel("Singular value index")
        ax.set_title(boundary.capitalize())
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Design matrix singular value")
    axes[0].legend(frameon=False, fontsize=6.7)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def fig_convergence(convergence: pd.DataFrame, path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0), sharex=True)
    models = ["rbf_radial_b32", "endpoint_full_b32", "endpoint_hybrid_b32", "mlp_endpoint_medium", "rbm_h32"]
    for ax, boundary in zip(axes, ["open", "periodic"]):
        for model, marker in zip(models, ["o", "s", "^", "D", "x"]):
            group = convergence[(convergence.boundary == boundary) & (convergence.model_label == model)]
            ax.plot(group.step, group.median_sampled_energy, marker=marker, markevery=2, markersize=2.5, linewidth=0.8, label=MODEL_DISPLAY[model])
        ax.set_title(boundary.capitalize())
        ax.set_xlabel("VMC iteration")
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Median sampled energy estimate")
    axes[0].legend(frameon=False, fontsize=6.2)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def tex_escape(text: str) -> str:
    replacements = {"_": r"\_", "%": r"\%", "&": r"\&", "#": r"\#"}
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def write_latex_tables(root: Path, summary: pd.DataFrame, endpoint_effects: pd.DataFrame, health: pd.DataFrame,
                       parameter_counts: pd.DataFrame, design_rank: pd.DataFrame, periodic: pd.DataFrame,
                       density_effects: pd.DataFrame) -> None:
    main_tables = root / "tables"
    supp_tables = root / "tables"
    main_tables.mkdir(parents=True, exist_ok=True)
    supp_tables.mkdir(parents=True, exist_ok=True)

    open_summary = summary[summary.boundary == "open"].set_index("model_label").reindex(MODEL_ORDER)
    lines = [
        r"\begin{table*}[t]",
        r"\caption{Open chain descriptive medians over 60 registered runs per model. Valid counts use the exact health gate; all runs, including flagged outcomes, remain in the medians. Lower errors are better.}",
        r"\label{tab:model-summary}",
        r"\begin{ruledtabular}",
        r"\begin{tabular}{lrrrrrr}",
        r"Model & Exact valid & $|E-E_0|$ & Density MAE & Corr. MAE & Parameters & Time (s) \\" ,
        r"\hline",
    ]
    for model, row in open_summary.iterrows():
        lines.append(
            f"{MODEL_DISPLAY[model]} & {int(row.exact_valid_runs)}/60 & {row.median_energy:.5g} & {row.median_density:.5g} & {row.median_correlation:.5g} & {int(row.parameters)} & {row.median_wall_seconds:.1f} \\\\" 
        )
    lines += [r"\end{tabular}", r"\end{ruledtabular}", r"\end{table*}"]
    (main_tables / "model_summary.tex").write_text("\n".join(lines) + "\n")

    data = endpoint_effects[(endpoint_effects.boundary == "open") & (endpoint_effects.control == "rbf_radial_b32") & endpoint_effects.treated.isin(ENDPOINT_MODELS)]
    lines = [
        r"\begin{table*}[t]",
        r"\caption{Paired open chain cell median effects relative to the radial RBF model. Entries are endpoint minus radial, with percentile intervals from 2.5 to 97.5 from 20,000 resamples of the 12 fixed Hamiltonian cells. Negative values favour endpoint conditioning.}",
        r"\label{tab:paired-effects}",
        r"\begin{ruledtabular}",
        r"\begin{tabular}{lccc}",
        r"Model & Energy error & Density MAE & Corr. MAE \\" ,
        r"\hline",
    ]
    for model in ENDPOINT_MODELS:
        entries = []
        for metric in ["energy", "density", "correlation"]:
            row = data[(data.treated == model) & (data.metric == metric)].iloc[0]
            entries.append(f"{row.median_delta:.4g} [{row.ci95_low:.4g}, {row.ci95_high:.4g}]")
        lines.append(f"{MODEL_DISPLAY[model]} & " + " & ".join(entries) + r" \\")
    lines += [r"\end{tabular}", r"\end{ruledtabular}", r"\end{table*}"]
    (main_tables / "paired_effects.tex").write_text("\n".join(lines) + "\n")

    # Supplement: full boundary/model summary.
    lines = [
        r"\begin{longtable}{llrrrrrrr}",
        r"\caption{Complete model and boundary summary.}\label{tab:supp-full-summary}\\",
        r"Boundary & Model & Runs & Exact valid & Sample valid & $|E-E_0|$ & Density & Corr. & Params \\",
        r"\hline",
        r"\endfirsthead",
        r"Boundary & Model & Runs & Exact valid & Sample valid & $|E-E_0|$ & Density & Corr. & Params \\",
        r"\hline",
        r"\endhead",
    ]
    for row in summary.itertuples(index=False):
        lines.append(
            f"{row.boundary.capitalize()} & {row.model} & {row.registered_runs} & {row.exact_valid_runs} & {row.sampled_valid_runs} & {row.median_energy:.5g} & {row.median_density:.5g} & {row.median_correlation:.5g} & {row.parameters} \\\\"
        )
    lines.append(r"\end{longtable}")
    (supp_tables / "full_model_summary.tex").write_text("\n".join(lines) + "\n")

    lines = [
        r"\begin{longtable}{lllr}",
        r"\caption{Parameter count derivations.}\label{tab:supp-parameter-counts}\\",
        r"Boundary & Model & Derivation & Count \\", r"\hline", r"\endfirsthead",
        r"Boundary & Model & Derivation & Count \\", r"\hline", r"\endhead",
    ]
    for row in parameter_counts.itertuples(index=False):
        lines.append(f"{row.boundary.capitalize()} & {row.model} & {tex_escape(row.derivation)} & {row.derived_parameters} \\\\"
        )
    lines.append(r"\end{longtable}")
    (supp_tables / "parameter_counts.tex").write_text("\n".join(lines) + "\n")

    lines = [
        r"\begin{table}[t]", r"\caption{Rank of the complete basis one body plus pair design matrix for the linear pair models.}",
        r"\label{tab:supp-design-rank}", r"\begin{ruledtabular}", r"\begin{tabular}{llrrr}",
        r"Boundary & Model & Columns & Rank & Nullity \\", r"\hline",
    ]
    for row in design_rank.itertuples(index=False):
        lines.append(f"{row.boundary.capitalize()} & {row.model} & {row.parameter_columns} & {row.numerical_rank} & {row.nullity} \\\\"
        )
    lines += [r"\end{tabular}", r"\end{ruledtabular}", r"\end{table}"]
    (supp_tables / "design_matrix_rank.tex").write_text("\n".join(lines) + "\n")

    lines = [
        r"\begin{table}[t]", r"\caption{Periodic endpoint disabled equality checks against the radial model.}",
        r"\label{tab:supp-periodic-equality}", r"\begin{ruledtabular}", r"\begin{tabular}{lrrr}",
        r"Variant & Pairs & Maximum metric delta & Equal checkpoints \\", r"\hline",
    ]
    for row in periodic.itertuples(index=False):
        max_delta = max(row.max_abs_energy_delta, row.max_abs_density_delta, row.max_abs_correlation_delta)
        lines.append(f"{row.model} & {row.paired_runs} & {max_delta:.1e} & {row.checkpoint_equal_count}/{row.paired_runs} \\\\"
        )
    lines += [r"\end{tabular}", r"\end{ruledtabular}", r"\end{table}"]
    (supp_tables / "periodic_equality.tex").write_text("\n".join(lines) + "\n")

    selected = density_effects[(density_effects.boundary == "open") & density_effects.treated.isin(["endpoint_hybrid_b32", "endpoint_full_b32"])]
    lines = [
        r"\begin{table}[t]", r"\caption{Open chain regional density error changes relative to radial RBF. Negative values favour endpoint conditioning.}",
        r"\label{tab:supp-regional-density}", r"\begin{ruledtabular}", r"\begin{tabular}{lrrr}",
        r"Model & Edge & Near edge & Bulk \\", r"\hline",
    ]
    for model in ["endpoint_hybrid_b32", "endpoint_full_b32"]:
        group = selected[selected.treated == model].set_index("region")
        lines.append(f"{MODEL_DISPLAY[model]} & {group.loc['edge','median_cell_delta']:.4f} & {group.loc['near_edge','median_cell_delta']:.4f} & {group.loc['bulk','median_cell_delta']:.4f} \\\\"
        )
    lines += [r"\end{tabular}", r"\end{ruledtabular}", r"\end{table}"]
    (supp_tables / "regional_density_effects.tex").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    source_root = args.source_root.resolve()
    output_root = args.output_root.resolve()
    metrics_path = source_root / "reports/stage4fr_final_20260721/analysis/tables/stage4fr_run_metrics.csv"
    runs_root = source_root / "results_stage4f_r/frozen/runs"
    if not metrics_path.exists() or not runs_root.exists():
        raise FileNotFoundError("Authoritative frozen campaign paths were not found")

    df = pd.read_csv(metrics_path)
    if len(df) != 960:
        raise RuntimeError(f"Expected 960 registered runs, found {len(df)}")
    site, corr, history = read_run_tables(runs_root)

    summary = model_boundary_summary(df)
    cells = cell_medians(df)
    paired = paired_effects(cells, controls=["rbf_radial_b32", "mlp_endpoint_medium"])
    regional, site_resolved, density_effects = density_summaries(site)
    corr_sep = correlation_by_separation(corr)
    periodic = periodic_invariance(df, runs_root)
    design_rank, singular_spectra = matrix_rank_records()
    gauge_values, gauge_coefficients, gauge_stability = gauge_diagnostics(df, runs_root)
    failure_details, failure_summary = failure_inventory(df)
    parameter_counts = parameter_count_table()
    convergence = convergence_summary(history)

    csv_dir = output_root / "source_data"
    npz_dir = output_root / "source_data" / "npz"
    csv_dir.mkdir(parents=True, exist_ok=True)
    npz_dir.mkdir(parents=True, exist_ok=True)
    save_csv(df, csv_dir / "stage4fr_run_metrics_authoritative.csv")
    save_csv(summary, csv_dir / "model_boundary_summary.csv")
    save_csv(cells, csv_dir / "cell_medians.csv")
    save_csv(paired, csv_dir / "paired_cell_effects.csv")
    save_csv(regional, csv_dir / "density_region_summary.csv")
    save_csv(site_resolved, csv_dir / "density_site_resolved.csv")
    save_csv(density_effects, csv_dir / "density_region_paired_effects.csv")
    save_csv(corr_sep, csv_dir / "correlation_by_separation.csv")
    save_csv(periodic, csv_dir / "periodic_invariance.csv")
    save_csv(design_rank, csv_dir / "design_matrix_rank.csv")
    save_csv(gauge_values, csv_dir / "gauge_fixed_pair_values.csv")
    save_csv(gauge_coefficients, csv_dir / "gauge_coefficients.csv")
    save_csv(gauge_stability, csv_dir / "gauge_stability.csv")
    save_csv(failure_details, csv_dir / "failure_inventory.csv")
    save_csv(failure_summary, csv_dir / "failure_summary.csv")
    save_csv(parameter_counts, csv_dir / "parameter_count_derivation.csv")
    save_csv(convergence, csv_dir / "convergence_summary.csv")
    np.savez_compressed(npz_dir / "design_matrix_singular_values.npz", **singular_spectra)

    main_fig = output_root / "figures"
    supp_fig = output_root / "figures"
    main_fig.mkdir(parents=True, exist_ok=True)
    supp_fig.mkdir(parents=True, exist_ok=True)
    fig_model_schematic(main_fig / "fig1_model_schematic.pdf")
    fig_model_metrics(summary, main_fig / "fig2_model_metrics.pdf")
    fig_paired_effects(paired, main_fig / "fig3_paired_effects.pdf")
    fig_density(site_resolved, regional, main_fig / "fig4_density_repair.pdf")
    fig_correlation(corr_sep, main_fig / "fig5_correlation_separation.pdf")
    fig_periodic_health(periodic, failure_summary, main_fig / "fig6_periodic_health.pdf")
    fig_gauge(gauge_values, gauge_stability, supp_fig / "figS1_gauge_diagnostic.pdf")
    fig_singular_values(singular_spectra, supp_fig / "figS2_design_singular_values.pdf")
    fig_convergence(convergence, supp_fig / "figS3_convergence_history.pdf")

    write_latex_tables(output_root, summary, paired, failure_summary, parameter_counts, design_rank, periodic, density_effects)

    full_endpoint = paired[(paired.boundary == "open") & (paired.treated == "endpoint_full_b32") & (paired.control == "rbf_radial_b32")].set_index("metric")
    full_mlp = paired[(paired.boundary == "open") & (paired.treated == "endpoint_full_b32") & (paired.control == "mlp_endpoint_medium")].set_index("metric")
    regional_full = density_effects[(density_effects.boundary == "open") & (density_effects.treated == "endpoint_full_b32")].set_index("region")
    result = {
        "generated_utc_note": "Generated in the execution environment; no new VMC campaign was run.",
        "source_root": f"<external-source>/{source_root.name}",
        "authoritative_metrics": str(metrics_path.relative_to(source_root)),
        "registered_runs": int(len(df)),
        "open_runs": int((df.boundary_condition == "open").sum()),
        "periodic_runs": int((df.boundary_condition == "periodic").sum()),
        "hamiltonian_cells_per_boundary": int(df[["boundary_condition", "delta", "c6"]].drop_duplicates().groupby("boundary_condition").size().iloc[0]),
        "seeds": sorted(int(x) for x in df.seed.unique()),
        "models": MODEL_ORDER,
        "exact_valid": int((df.scientific_validity_exact == "VALID").sum()),
        "sampled_valid": int((df.scientific_validity_sample == "VALID").sum()),
        "bootstrap_reps": BOOTSTRAP_REPS,
        "bootstrap_seed": BOOTSTRAP_SEED,
        "endpoint_full_minus_radial": {
            metric: {
                "median": float(full_endpoint.loc[metric, "median_delta"]),
                "low": float(full_endpoint.loc[metric, "ci95_low"]),
                "high": float(full_endpoint.loc[metric, "ci95_high"]),
            }
            for metric in ["energy", "density", "correlation"]
        },
        "endpoint_full_minus_mlp_medium": {
            metric: {
                "median": float(full_mlp.loc[metric, "median_delta"]),
                "low": float(full_mlp.loc[metric, "ci95_low"]),
                "high": float(full_mlp.loc[metric, "ci95_high"]),
                "fraction_treated_lower": float(full_mlp.loc[metric, "fraction_cells_treated_lower"]),
            }
            for metric in ["energy", "density", "correlation"]
        },
        "endpoint_full_density_region_minus_radial": {
            region: float(regional_full.loc[region, "median_cell_delta"])
            for region in ["edge", "near_edge", "bulk"]
        },
        "periodic_paired_metric_comparisons": int(periodic.paired_runs.sum()),
        "periodic_equal_checkpoints": int(periodic.checkpoint_equal_count.sum()),
        "pytest_status": "Recorded separately by build orchestration",
        "python": sys.version,
        "platform": platform.platform(),
    }
    scripts_dir = output_root / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    (output_root / "source_data" / "recomputed_summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    (scripts_dir / "analysis_environment.txt").write_text(
        f"Python: {sys.version}\nPlatform: {platform.platform()}\nNumPy: {np.__version__}\nPandas: {pd.__version__}\nMatplotlib: {matplotlib.__version__}\n"
    )
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
