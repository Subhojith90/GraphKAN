"""Independent checks of equations in the 28 October 2026 GraphKAN PDFs.

This does NOT read the authors' code, checkpoints, or primary campaign data.
All constructions below are newly implemented from the manuscript equations.
Requires NumPy only. Outputs JSON to the supplied path.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('OMP_NUM_THREADS', '2')
import sys, json, time
from pathlib import Path
import numpy as np

def construct(n, periodic, c6=4.0, k=32):
    states = np.arange(2**n, dtype=np.int64)
    occ = ((states[:, None] >> np.arange(n)) & 1).astype(float)
    ii,jj=np.triu_indices(n,1)
    distance=(jj-ii).astype(float)
    if periodic: distance=np.minimum(distance,n-distance)
    x=distance/c6**(1/6)
    centers=np.linspace(x.min(),x.max(),k)
    width=max(float(centers[1]-centers[0]),1e-6)
    rb=np.exp(-0.5*((x[:,None]-centers)/width)**2)
    d=np.minimum(np.arange(n),n-1-np.arange(n)).astype(float)
    d/=d.max()
    end=np.column_stack((d[ii]+d[jj],np.abs(d[ii]-d[jj]),d[ii]*d[jj]))
    if periodic: end[:]=0
    products=occ[:,ii]*occ[:,jj]
    return states,occ,ii,jj,distance,rb,end,products

def observables(psi,occ):
    probs=psi**2
    dens=probs@occ
    corr=occ.T@(probs[:,None]*occ)-np.outer(dens,dens)
    return dens,corr

def audit():
    result={'scope':'Independent mathematical reconstruction, not author-code reproduction',
            'numpy_version':np.__version__, 'rank_checks':[], 'gauge_checks':[],
            'rbf_scale_cancellation':[], 'spectral_checks':[]}
    rng=np.random.default_rng(20261030)
    for n in (10,12):
      for periodic in (False,True):
        states,occ,ii,jj,dist,rb,end,prod=construct(n,periodic)
        X=np.column_stack((occ,prod@rb))
        for label,selection in [('radial',[]),('sum',[0]),('product',[2]),('hybrid',[0,2]),('full',[0,1,2])]:
            # Periodic aliases remove endpoint parameters before initialization.
            pair=rb if periodic or not selection else np.column_stack((rb,end[:,selection]))
            design=np.column_stack((occ,prod@pair))
            u,s,vt=np.linalg.svd(design,full_matrices=False)
            tol=s[0]*max(design.shape)*np.finfo(float).eps
            rank=int((s>tol).sum())
            result['rank_checks'].append({'n':n,'periodic':periodic,'model':label,
                'columns':design.shape[1],'rank':rank,'nullity':design.shape[1]-rank})
            if label=='full' and not periodic:
                theta=rng.normal(size=design.shape[1])
                projected=vt[:rank].T@(vt[:rank]@theta)
                A=design@theta
                single_idx=1<<np.arange(n)
                pair_idx=(1<<ii)+(1<<jj)
                recovered=A[pair_idx]-A[single_idx[ii]]-A[single_idx[jj]]+A[0]
                F=pair@theta[n:]
                F2=pair@projected[n:]
                z=prod@end
                ux,sx,vtx=np.linalg.svd(X,full_matrices=False)
                rx=int(np.linalg.matrix_rank(X))
                zperp=z-ux[:,:rx]@(ux[:,:rx].T@z)
                result['gauge_checks'].append({'n':n,
                    'max_log_amplitude_delta':float(np.max(np.abs(design@projected-A))),
                    'max_pair_value_delta':float(np.max(np.abs(F-F2))),
                    'max_pair_recovery_error':float(np.max(np.abs(recovered-F))),
                    'removed_coefficient_norm_fraction':float(np.linalg.norm(theta-projected)/np.linalg.norm(theta)),
                    'raw_space_rank':rank,
                    'orthogonal_space_rank':int(np.linalg.matrix_rank(np.column_stack((X,zperp)))),
                    'base_to_residual_orthogonality_max':float(np.max(np.abs(X.T@zperp)))})
        rb3=construct(n,periodic,3)[5]
        rb5=construct(n,periodic,5)[5]
        result['rbf_scale_cancellation'].append({'n':n,'periodic':periodic,
            'max_basis_delta_c6_3_vs_5':float(np.max(np.abs(rb3-rb5)))})
    result['normalization_check']={
        'N10_correct_endpoint_values':(np.minimum(np.arange(10),9-np.arange(10))/4).tolist(),
        'N10_figure_formula_maximum_if_denominator_4_5':4/4.5,
        'note':'Figure formula read from extracted text; rendered original still requires visual confirmation.'}
    result['counts']={'primary_nominal':2*4*3*8*5,'periodic_alias_pairs':4*12*5,
        'distinct_primary_trajectories_after_periodic_aliases':960-240,
        'exact_valid':58+6*60+5*60+59+54,
        'sampled_valid':7*60+5*59+54+51,
        'confirmation':3*5*4,'counterfactual':1*5*3,
        'open_mlp_medium':10+15*7+7+7+1,
        'open_mlp_large':10+20*11+11+11+1,
        'open_dense_pair_parameters':10+10*9//2,
        'open_reflection_pair_independent_site_parameters':10+(45+5)//2}
    # Ground-state checks and an intentionally constructed translation-asymmetric
    # example. These examples do not establish the cause of the archived RBM data.
    n=10
    for periodic in (False,True):
        states,occ,ii,jj,dist,rb,end,prod=construct(n,periodic)
        off=np.zeros((2**n,2**n))
        for site in range(n): off[states,states^(1<<site)]=-0.5
        parity=(-1.0)**occ.sum(axis=1)
        for delta in (1.25,1.50,1.75,2.00):
          for c6 in (3.0,4.0,5.0):
            start=time.time()
            diag=-delta*occ.sum(axis=1)+prod@(c6/dist**6)
            H=off.copy()
            np.fill_diagonal(H,diag)
            eig,vec=np.linalg.eigh(H)
            ground=vec[:,0]
            if ground.sum()<0: ground=-ground
            density,corr=observables(ground,occ)
            row={'n':n,'periodic':periodic,'delta':delta,'c6':c6,
                 'E0':float(eig[0]),'gap':float(eig[1]-eig[0]),
                 'eigen_residual_norm':float(np.linalg.norm(H@ground-eig[0]*ground)),
                 'mean_density':float(density.mean()),'min_ground_amplitude_negative_field':float(ground.min()),
                 'parity_unitary_error':float(np.max(np.abs(parity[:,None]*H*parity[None,:]-(np.diag(diag)-off))))}
            if periodic:
                # Equal superposition of the lowest two exact eigenstates.
                branch=(vec[:,0]+vec[:,1])/np.sqrt(2)
                dn,dc=observables(branch,occ)
                mask=~np.eye(n,dtype=bool)
                row['illustrative_low_doublet_state']={
                    'energy_error':float(branch@H@branch-eig[0]),
                    'density_mae':float(np.abs(dn-density).mean()),
                    'correlation_mae':float(np.abs(dc-corr)[mask].mean()),
                    'ground_state_fidelity':float((ground@branch)**2)}
            result['spectral_checks'].append(row)
            print(json.dumps({'progress':'ED cell complete','periodic':periodic,'delta':delta,'c6':c6,'seconds':round(time.time()-start,3)}),flush=True)
    return result

if __name__=='__main__':
    out=Path(sys.argv[1] if len(sys.argv)>1 else 'independent_check_results.json')
    out.parent.mkdir(parents=True,exist_ok=True)
    result=audit()
    out.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(out.resolve()),'status':'complete'}),flush=True)
