"""Exploratory deterministic optimization from published equations, no author data.

This is NOT a replay of the VMC protocol and is NOT a global optimum certificate.
NumPy-only, centered orthonormal feature coordinates, BFGS and Armijo search.
"""
import json
import argparse
import os
from pathlib import Path
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('OMP_NUM_THREADS', '2')
import numpy as np
from independent_checks import construct, observables

def bfgs(fun,x,gtol=1e-8,maxiter=1000):
    E,g=fun(x); inv=np.eye(len(x)); reason='iteration_limit'
    for it in range(maxiter):
        if np.max(np.abs(g))<gtol:
            reason='gradient_tolerance'; break
        direction=-inv@g
        if g@direction>=0:
            inv=np.eye(len(x)); direction=-g
        step=1.0
        for ls in range(45):
            xx=x+step*direction; EE,gg=fun(xx)
            if np.isfinite(EE) and EE<=E+1e-4*step*(g@direction): break
            step*=0.5
        else:
            reason='line_search_stalled'; break
        ss=xx-x; yy=gg-g; sy=float(ss@yy)
        if sy>1e-13*np.linalg.norm(ss)*np.linalg.norm(yy) and sy>0:
            rho=1/sy; eye=np.eye(len(x)); tmp=eye-rho*np.outer(ss,yy)
            inv=tmp@inv@tmp.T+rho*np.outer(ss,ss)
        x,E,g=xx,EE,gg
    return x,{'iterations':it+1,'stop':reason,'gradient_inf':float(np.max(np.abs(g))),'energy':float(E)}

def run(output_path: Path):
    n=10; delta=2.0; c6=5.0
    states,occ,ii,jj,dist,rb,end,prod=construct(n,False,c6)
    diag=-delta*occ.sum(axis=1)+prod@(c6/dist**6)
    flips=states[:,None]^(1<<np.arange(n))
    def apply_h(psi): return diag*psi-0.5*psi[flips].sum(axis=1)
    H=np.diag(diag)
    for site in range(n):H[states,states^(1<<site)]=-0.5
    eig,vec=np.linalg.eigh(H); gs=vec[:,0]
    dn0,dc0=observables(gs,occ); mask=~np.eye(n,dtype=bool)
    output={'scope':'Exploratory exact optimization, no author code/checkpoints, no claim of global optimality',
        'N':n,'delta':delta,'C6':c6,'E0':float(eig[0]),'gap':float(eig[1]-eig[0]),'runs':[]}
    models={'radial':np.column_stack((occ,prod@rb)),
            'endpoint_full':np.column_stack((occ,prod@rb,prod@end))}
    for model,raw in models.items():
        centered=raw-raw.mean(axis=0)
        u,s,vt=np.linalg.svd(centered,full_matrices=False)
        rank=np.linalg.matrix_rank(centered); Q=u[:,:rank]*np.sqrt(len(states))
        def state(theta):
            A=Q@theta; psi=np.exp(A-A.max());return psi/np.linalg.norm(psi)
        def energy_gradient(theta):
            psi=state(theta); hp=apply_h(psi); energy=psi@hp
            return float(energy),2*Q.T@(psi*(hp-energy*psi))
        rng=np.random.default_rng(47)
        probe=rng.normal(scale=0.03,size=rank)
        _,grad=energy_gradient(probe); eps=1e-6
        numeric=np.zeros(rank)
        for j in range(rank):
            d=np.zeros(rank);d[j]=eps
            numeric[j]=(energy_gradient(probe+d)[0]-energy_gradient(probe-d)[0])/(2*eps)
        grad_diff=float(np.max(np.abs(grad-numeric)))
        for seed,scale in [(0,0.0),(1,0.03),(2,0.1)]:
            initial=np.random.default_rng(seed).normal(scale=scale,size=rank)
            theta,info=bfgs(energy_gradient,initial)
            psi=state(theta);dn,dc=observables(psi,occ);hp=apply_h(psi)
            info.update({'model':model,'seed':seed,'rank':int(rank),'initial_scale':scale,
                'energy_error':float(info['energy']-eig[0]),
                'density_mae':float(np.abs(dn-dn0).mean()),
                'correlation_mae':float(np.abs(dc-dc0)[mask].mean()),
                'fidelity':float((psi@gs)**2),
                'energy_variance':float(np.linalg.norm(hp-info['energy']*psi)**2),
                'gradient_finite_difference_max_error':grad_diff,
                'dense_vs_matrix_free_energy_delta':float(abs(psi@H@psi-info['energy']))})
            output['runs'].append(info)
            print(json.dumps(info),flush=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(output_path.resolve()),'status':'complete'}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path('audit_work/exact_optimization_probe.json'))
    args=parser.parse_args()
    run(args.output)
