"""Translation projection diagnostic for all archived periodic RBM states.

The script reads only the frozen run directories supplied in the master evidence
archive. Exact references are reconstructed directly, so no private intermediate
CSV or reference NPZ files are required. The projected state is diagnostic and is
not generally a single RBM of the original architecture.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def exact_reference(n: int, delta: float, c6: float):
    idx = np.arange(1 << n)
    bits = 1 << np.arange(n - 1, -1, -1)
    occ = ((idx[:, None] >> np.arange(n - 1, -1, -1)) & 1).astype(float)
    flips = idx[:, None] ^ bits
    pair_i, pair_j = np.triu_indices(n, 1)
    distance = np.minimum(abs(pair_i - pair_j), n - abs(pair_i - pair_j))
    pair = occ[:, pair_i] * occ[:, pair_j]
    diagonal = -delta * occ.sum(axis=1) + pair @ (c6 / distance.astype(float) ** 6)
    hamiltonian = np.diag(diagonal)
    for site in range(n):
        hamiltonian[idx, idx ^ bits[site]] = -0.5
    energies, vectors = np.linalg.eigh(hamiltonian)
    ground = vectors[:, 0]
    if ground.sum() < 0:
        ground = -ground
    probability = ground * ground
    density = probability @ occ
    correlation = (occ.T * probability) @ occ - np.outer(density, density)
    return idx, bits, occ, flips, pair, distance, float(energies[0]), ground, density, correlation


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    runs_root = args.repository / "results_stage4f_r/frozen/runs"
    run_dirs = sorted(
        path
        for path in runs_root.iterdir()
        if path.is_dir() and "__Bperiodic__" in path.name and "__Mrbm_h32__" in path.name
    )
    if len(run_dirs) != 60:
        raise RuntimeError(f"Expected 60 periodic RBM runs, found {len(run_dirs)}")

    args.output.mkdir(parents=True, exist_ok=True)
    references = {}
    rows = []
    n = 10
    mask = ~np.eye(n, dtype=bool)

    for run_dir in run_dirs:
        manifest = json.loads((run_dir / "run_manifest.json").read_text())
        delta = float(manifest["delta"])
        c6 = float(manifest["c6"])
        key = (delta, c6)
        if key not in references:
            references[key] = exact_reference(n, delta, c6)
        idx, bits, occ, flips, pair, distance, e0, ground, density0, corr0 = references[key]

        checkpoint = np.load(run_dir / "checkpoint.npz")
        arrays = [checkpoint[name] for name in checkpoint.files]
        amplitude = occ @ arrays[1] + np.logaddexp(0, occ @ arrays[2] + arrays[0]).sum(axis=1)
        psi = np.exp(amplitude - amplitude.max())
        psi /= np.linalg.norm(psi)

        translated_indices = [np.roll(occ.astype(int), shift, axis=1) @ bits for shift in range(n)]
        projected = sum(psi[permutation] for permutation in translated_indices)
        projected /= np.linalg.norm(projected)

        def state_metrics(state):
            probability = state * state
            diagonal = -delta * occ.sum(axis=1) + pair @ (c6 / distance.astype(float) ** 6)
            energy = float(state @ (diagonal * state - 0.5 * state[flips].sum(axis=1)))
            density = probability @ occ
            correlation = (occ.T * probability) @ occ - np.outer(density, density)
            return {
                "energy_error": energy - e0,
                "density_mae": float(np.abs(density - density0).mean()),
                "correlation_mae": float(np.abs(correlation - corr0)[mask].mean()),
                "fidelity": float((ground @ state) ** 2),
                "absolute_staggered_density": float(abs(np.mean(((-1) ** np.arange(n)) * density))),
            }

        original = state_metrics(psi)
        projected_metrics = state_metrics(projected)
        record = {
            "run_id": manifest["run_id"],
            "delta": delta,
            "c6": c6,
            "seed": int(manifest["seed"]),
        }
        record.update({f"original_{key}": value for key, value in original.items()})
        record.update({f"translation_projected_{key}": value for key, value in projected_metrics.items()})
        rows.append(record)

    table = pd.DataFrame(rows)
    table.to_csv(args.output / "rbm_translation_projection.csv", index=False)
    result = {
        "runs": len(table),
        "operation": "Normalized sum of all ten one site translations of each saved positive gauge amplitude; not a newly trained RBM, and not generally a single RBM of the original architecture.",
        "medians": {
            column: float(table[column].median())
            for column in table
            if column.startswith(("original_", "translation_"))
        },
        "improved_counts": {
            metric: int(
                (
                    table[f"translation_projected_{metric}"]
                    < table[f"original_{metric}"]
                ).sum()
            )
            for metric in ("energy_error", "density_mae", "correlation_mae")
        },
        "projected_exact_health_valid": int(
            (
                (table.translation_projected_energy_error <= 0.5)
                & (table.translation_projected_density_mae <= 0.08)
                & (table.translation_projected_correlation_mae <= 0.08)
            ).sum()
        ),
        "all_errors": {
            column: [float(table[column].min()), float(table[column].max())]
            for column in table
            if column.startswith("translation_")
        },
    }
    summary = args.output / "rbm_translation_projection_summary.json"
    summary.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": str(summary.resolve()), "status": "complete", **result}, indent=2))


if __name__ == "__main__":
    main()
