#!/usr/bin/env python3
"""Verify the archived GraphKAN manuscript evidence without retraining models."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_payload_runs(runs_root: Path, expected: int) -> tuple[int, int, list[str]]:
    runs = sorted(path for path in runs_root.iterdir() if path.is_dir())
    errors: list[str] = []
    checked = 0
    for run in runs:
        completion_path = run / "completion.json"
        if not completion_path.is_file():
            errors.append(f"missing completion record: {run.name}")
            continue
        completion = json.loads(completion_path.read_text())
        if completion.get("status") != "COMPLETED":
            errors.append(f"nonterminal run: {run.name}")
            continue
        attempt = run / "attempts" / str(completion.get("attempt", ""))
        for relative, expected_hash in completion.get("payload_hashes", {}).items():
            path = attempt / relative
            if not path.is_file():
                errors.append(f"missing payload: {run.name}/{relative}")
            elif sha256(path) != expected_hash:
                errors.append(f"payload hash mismatch: {run.name}/{relative}")
            else:
                checked += 1
    if len(runs) != expected:
        errors.append(f"run count is {len(runs)}, expected {expected}")
    return len(runs), checked, errors


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("evidence_repository"))
    parser.add_argument("--output", type=Path, default=Path("validation/evidence_inventory.json"))
    args = parser.parse_args()
    root = args.root.resolve()
    errors: list[str] = []

    n10_root = root / "results_stage4f_r/frozen/runs"
    n10_runs = sorted(path for path in n10_root.iterdir() if path.is_dir())
    required_n10 = {
        "COMPLETE.json",
        "checkpoint.npz",
        "metrics.csv",
        "site_observables.csv",
        "corr_observables.csv",
        "history.csv",
    }
    for run in n10_runs:
        missing = sorted(name for name in required_n10 if not (run / name).is_file())
        if missing:
            errors.append(f"N10 missing {missing}: {run.name}")
    if len(n10_runs) != 960:
        errors.append(f"N10 run count is {len(n10_runs)}, expected 960")

    h_root = root / "results_stage4h/local_campaign_20260807/merged/runs"
    i_root = root / "results_stage4i/local_campaign_20260810/merged/runs"
    h_runs, h_payloads, h_errors = verify_payload_runs(h_root, 60)
    i_runs, i_payloads, i_errors = verify_payload_runs(i_root, 15)
    errors.extend(h_errors)
    errors.extend(i_errors)

    orthogonal_attestations = len(
        list(i_root.glob("*orthogonal*/attempts/*/orthogonalisation_attestation.json"))
    )
    orthogonal_projections = len(
        list(i_root.glob("*orthogonal*/attempts/*/orthogonalisation_projection.npz"))
    )
    if orthogonal_attestations != 5 or orthogonal_projections != 5:
        errors.append(
            "Stage 4I orthogonal evidence is incomplete: "
            f"{orthogonal_attestations} attestations and {orthogonal_projections} projections"
        )

    h_gate = json.loads(
        (
            root
            / "results_stage4h/local_campaign_20260807/merged/analysis/stage4h_final_gate.json"
        ).read_text()
    )
    i_gate = json.loads(
        (
            root
            / "results_stage4i/local_campaign_20260810/merged/stage4i_final_gate.json"
        ).read_text()
    )
    if h_gate.get("validation") != "PASS":
        errors.append("archived Stage 4H gate is not PASS")
    if i_gate.get("validation") != "PASS":
        errors.append("archived Stage 4I gate is not PASS")

    result = {
        "schema_version": "graphkan_manuscript_evidence_inventory_v1",
        "validation": "PASS" if not errors else "FAIL",
        "blocking_errors": errors,
        "n10_runs": len(n10_runs),
        "stage4h_runs": h_runs,
        "stage4h_payload_hashes_verified": h_payloads,
        "stage4i_runs": i_runs,
        "stage4i_payload_hashes_verified": i_payloads,
        "stage4i_orthogonal_attestations": orthogonal_attestations,
        "stage4i_orthogonal_projections": orthogonal_projections,
        "stage4h_decision": h_gate.get("decision_class"),
        "stage4i_decision": i_gate.get("decision_class"),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
