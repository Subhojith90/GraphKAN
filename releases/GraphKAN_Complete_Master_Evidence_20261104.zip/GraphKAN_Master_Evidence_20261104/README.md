# GraphKAN corrected manuscript and complete evidence package

This package closes the pre submission corrections requested in the October 2026 scientific audit.

## Contents

- `manuscript/` contains the corrected main paper, Supplemental Material, figures, tables, bibliography, and deterministic manuscript analysis.
- `evidence_repository/` contains the complete frozen $N=10$ campaign, all Stage 4H evidence, all Stage 4I evidence, protocols, source code, requirements, and tests.
- `evidence_archives/` preserves the independently checksummed Stage 4H and Stage 4I release archives.
- `source_snapshots/stage4h/` preserves the exact Stage 4H helper that closes the frozen Stage 4H source ledger before the later Stage 4I aliases were added.
- `scripts/verify_evidence_inventory.py` verifies run counts and every registered Stage 4H and Stage 4I payload hash.
- `reproduce_all.sh` regenerates the manuscript analysis and reruns the Stage 4H and Stage 4I scientific decisions without training new models.
- `validation/final_20261104/` contains the compilation, clean extraction diagnostic, complete reproduction, inventory, and archive integrity records for this exact release.

## Reproduction

From the package root, run:

```bash
bash reproduce_all.sh
```

The command requires the Python environment recorded under `evidence_repository/requirements/`. It does not perform variational Monte Carlo training.

The two added diagnostics can also be run independently from the package root:

```bash
python manuscript/scripts/audit_diagnostics/exact_optimization_probe.py \
  --output validation/diagnostics/exact_optimization_probe.json

python manuscript/scripts/audit_diagnostics/rbm_symmetry_probe.py \
  --repository evidence_repository \
  --output validation/diagnostics/rbm_symmetry
```

The exact optimisation probe requires NumPy. The RBM projection additionally requires pandas and the complete frozen campaign included in `evidence_repository/`. Both commands create their output directories automatically.

## Scientific corrections

The corrected manuscript distinguishes pooled run medians from paired cell effects, treats the Stage 4I orthogonal construction as an equivalent representation, avoids attributing the different $N=10$ and $N=12$ outcomes to size alone, labels the scale associations as exploratory, and describes checkpoint equality at the tensor level rather than the raw archive byte level.

The Nature Physics study by Mauron, Denis, Nys, and Carleo is included in the literature discussion and explicitly distinguished from the present one dimensional open chain analysis.

## Remaining external action

This master archive is the complete reviewer package. The manuscript source archive is intentionally smaller and does not contain the run and checkpoint collection. A public archive DOI or repository address must be inserted only after the final master archive is deposited and tested without authentication. See `PUBLIC_ARCHIVE_ACTION_REQUIRED.md`.
