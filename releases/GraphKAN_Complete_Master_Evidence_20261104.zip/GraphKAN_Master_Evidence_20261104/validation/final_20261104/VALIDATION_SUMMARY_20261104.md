# Final package validation summary

Date: November 4, 2026

## Results

- Complete evidence inventory: PASS
- Registered ten site runs: 960
- Twelve site continuation runs: 60
- Orthogonal counterfactual runs: 15
- Complete deterministic reconstruction: PASS
- Archived scientific decision equality: PASS for all three decision records
- Exact optimisation diagnostic reproduction: PASS for six radial and endpoint full rows
- Periodic RBM translation projection: PASS for all 60 archived controls
- Repository tests: 147 passed and 1 optional test skipped
- Main manuscript compilation: PASS, 15 pages
- Supplemental Material compilation: PASS, 13 pages
- Undefined references or citations: none
- Missing figures or tables: none
- Overfull boxes: none
- Visual inspection: all 28 pages passed

## Clean extraction commands

```bash
python manuscript/scripts/audit_diagnostics/exact_optimization_probe.py \
  --output validation/clean_test/exact_optimization_probe.json

python manuscript/scripts/audit_diagnostics/rbm_symmetry_probe.py \
  --repository evidence_repository \
  --output validation/clean_test/rbm_symmetry

bash reproduce_all.sh /tmp/graphkan_reconstruction
```

The complete reconstruction and diagnostics read archived evidence and do not train new variational states.
