# Validation summary

This record describes the corrected package before archive assembly.

## Scientific reconstruction

- Complete evidence inventory: PASS
- Frozen N10 campaign: 960 registered trajectories
- Stage 4H terminal campaign: 60 runs
- Stage 4H payload hashes: 3600 verified
- Stage 4I counterfactual campaign: 15 runs
- Stage 4I payload hashes: 930 verified
- Stage 4H decision regeneration: byte identical to the archived decision
- Stage 4I gauge decision regeneration: byte identical to the archived decision
- Stage 4I final decision regeneration: byte identical to the archived decision
- Complete reproduction gate: PASS

## Source and manuscript

- Repository test suite: PASS, 147 passed and 1 optional test skipped
- Main manuscript compilation: PASS, 15 pages
- Supplemental Material compilation: PASS, 13 pages
- Undefined references or citations: 0
- Final pass overfull boxes: 0
- Visual quality inspection: PASS
- Main manuscript SHA 256: `363ea1e2d6c5be8a1a420aa2c59cee607cc4fa0d5d6933f8badbc0304651c0a2`
- Supplemental Material SHA 256: `c9d8d341965a2a29d11b093e535ac1047fd44bacea6765dcf68c05f4a002ab05`

## External action

The public archive DOI and unauthenticated repository address remain pending. They must be inserted only after the authors publish and test the final immutable deposit.
