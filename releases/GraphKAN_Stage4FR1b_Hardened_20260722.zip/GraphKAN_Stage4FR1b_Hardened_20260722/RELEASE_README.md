# GraphKAN Stage 4F-R.1 byte-preserving release

All 960 canonical bundles and 11,520 payload bytes verify exactly. The 105-file frozen execution source is reconstructed under `frozen_execution_source/`.

Run `./verify_repository.sh` after extraction. The hardened independent 20-run Ubuntu replay remains explicitly PENDING until the GitHub workflow artifact is returned and audited.
